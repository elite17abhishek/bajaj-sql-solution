package com.example.demo;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@SpringBootApplication
public class DemoApplication {

    private final WebClient webClient;

    public DemoApplication(WebClient.Builder builder) {
        this.webClient = builder.baseUrl("https://bfhldevapigw.healthrx.co.in").build();
    }

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @PostConstruct
    public void startProcess() {
        // 🔑 Use your own regNo here (we cannot rely on response)
        String myRegNo = "REG12347";

        // Step 1: Send request to generate webhook
        String requestBody = """
                {
                  "name": "John Doe",
                  "regNo": "REG12347",
                  "email": "john@example.com"
                }
                """;

        WebhookResponse response = webClient.post()
                .uri("/hiring/generateWebhook/JAVA")
                .contentType(MediaType.APPLICATION_JSON)
                .body(Mono.just(requestBody), String.class)
                .retrieve()
                .bodyToMono(WebhookResponse.class)
                .block();

        if (response != null) {
            System.out.println("✅ Webhook URL: " + response.getWebhook());
            System.out.println("✅ Access Token: " + response.getAccessToken());

            // Step 2: Solve SQL question based on myRegNo
            String sqlQuery = solveSQL(myRegNo);

            // Step 3: Submit answer
            submitAnswer(response.getWebhook(), response.getAccessToken(), sqlQuery);
        }
    }

    // Decide SQL query based on regNo last 2 digits
    private String solveSQL(String regNo) {
        int lastDigits = Integer.parseInt(regNo.substring(regNo.length() - 2));
        if (lastDigits % 2 == 0) {
            // Example for Question 2 (replace with correct SQL once you read PDF)
            return "SELECT * FROM students WHERE marks > 50;";
        } else {
            // Example for Question 1 (replace with correct SQL once you read PDF)
            return "SELECT department, COUNT(*) FROM employees GROUP BY department;";
        }
    }

    // Submit SQL answer to webhook
    private void submitAnswer(String webhook, String token, String query) {
        String body = "{ \"finalQuery\": \"" + query + "\" }";

        String result = webClient.post()
                .uri(webhook)
                .header("Authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .body(Mono.just(body), String.class)
                .retrieve()
                .bodyToMono(String.class)
                .block();

        System.out.println("✅ Submitted Answer Response: " + result);
    }
}
